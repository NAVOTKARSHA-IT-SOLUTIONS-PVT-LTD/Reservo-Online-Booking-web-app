package com.reservo.backend.repository;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.Query;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.reservo.backend.entity.User;

@Slf4j
@Repository
public class UserRepository {

    private static final String COLLECTION = "users";

    private final Firestore firestore;
    private final java.util.Map<String, User> memoryStoreById = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.Map<String, User> memoryStoreByEmail = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.Map<String, User> memoryStoreByPhone = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.Map<String, User> memoryStoreByProvider = new java.util.concurrent.ConcurrentHashMap<>();

    public UserRepository(Firestore firestore) {
        this.firestore = firestore;
    }

    private void cacheUser(User user) {
        if (user == null || user.getId() == null) return;
        memoryStoreById.put(user.getId(), user);
        if (user.getEmail() != null) {
            memoryStoreByEmail.put(user.getEmail().trim().toLowerCase(), user);
        }
        if (user.getPhone() != null) {
            String norm = normalizePhoneNumber(user.getPhone());
            if (norm != null) memoryStoreByPhone.put(norm, user);
        }
        if (user.getProviderUserId() != null) {
            memoryStoreByProvider.put(user.getProviderUserId(), user);
        }
    }


    // ============================================================
    // FIND BY ID
    // ============================================================

    public Optional<User> findById(String id) {

        if (id == null || id.isBlank()) {
            return Optional.empty();
        }

        try {

            var snapshot = firestore
                    .collection(COLLECTION)
                    .document(id)
                    .get()
                    .get();

            if (snapshot.exists()) {
                User user = mapDocument(snapshot);
                if (user != null) {
                    cacheUser(user);
                    return Optional.of(user);
                }
            }

        } catch (Exception e) {
            log.debug("Firestore findById unavailable, checking local cache: {}", e.getMessage());
        }

        return Optional.ofNullable(memoryStoreById.get(id));
    }


    // ============================================================
    // SAVE
    // ============================================================

    public User save(User user) {

        if (user == null) {
            throw new IllegalArgumentException(
                    "User cannot be null"
            );
        }

        if (user.getId() == null
                || user.getId().isBlank()) {

            String newId = null;
            try {
                newId = firestore
                        .collection(COLLECTION)
                        .document()
                        .getId();
            } catch (Exception ignored) {}

            if (newId == null || newId.isBlank()) {
                newId = java.util.UUID.randomUUID().toString();
            }
            user.setId(newId);
        }

        if (user.getCreatedAt() == null) {
            user.setCreatedAt(Instant.now());
        }

        user.updateTimestamp();
        cacheUser(user);

        try {

            firestore
                    .collection(COLLECTION)
                    .document(user.getId())
                    .set(user)
                    .get();

        } catch (Exception e) {
            log.warn("Firestore write skipped/unavailable (cached in-memory): {}", e.getMessage());
        }

        return user;
    }


    // ============================================================
    // FIND BY EMAIL
    // ============================================================

    public Optional<User> findByEmail(
            String email) {

        if (email == null || email.isBlank()) {
            return Optional.empty();
        }

        String normalizedEmail =
                email.trim().toLowerCase();

        try {

            Query query = firestore
                    .collection(COLLECTION)
                    .whereEqualTo(
                            "email",
                            normalizedEmail
                    )
                    .limit(1);

            List<QueryDocumentSnapshot> documents =
                    query
                            .get()
                            .get()
                            .getDocuments();

            if (!documents.isEmpty()) {
                User user = mapDocument(documents.get(0));
                if (user != null) {
                    cacheUser(user);
                    return Optional.of(user);
                }
            }

        } catch (Exception e) {
            log.debug("Firestore findByEmail unavailable, checking local cache: {}", e.getMessage());
        }

        return Optional.ofNullable(memoryStoreByEmail.get(normalizedEmail));
    }


    // ============================================================
    // FIND BY PROVIDER USER ID
    // ============================================================

    public Optional<User> findByProviderUserId(
            String providerUserId) {

        if (providerUserId == null
                || providerUserId.isBlank()) {

            return Optional.empty();
        }

        try {

            Query query = firestore
                    .collection(COLLECTION)
                    .whereEqualTo(
                            "providerUserId",
                            providerUserId
                    )
                    .limit(1);

            List<QueryDocumentSnapshot> documents =
                    query
                            .get()
                            .get()
                            .getDocuments();

            if (!documents.isEmpty()) {
                User user = mapDocument(documents.get(0));
                if (user != null) {
                    cacheUser(user);
                    return Optional.of(user);
                }
            }

        } catch (Exception e) {
            log.debug("Firestore findByProviderUserId unavailable, checking local cache: {}", e.getMessage());
        }

        return Optional.ofNullable(memoryStoreByProvider.get(providerUserId));
    }


    // ============================================================
    // FIND BY PHONE
    // ============================================================

    public Optional<User> findByPhone(
            String phone) {

        if (phone == null || phone.isBlank()) {
            return Optional.empty();
        }

        String normalizedPhone =
                normalizePhoneNumber(phone);

        try {

            Query query = firestore
                    .collection(COLLECTION)
                    .whereEqualTo(
                            "phone",
                            normalizedPhone
                    )
                    .limit(1);

            List<QueryDocumentSnapshot> documents =
                    query
                            .get()
                            .get()
                            .getDocuments();

            if (!documents.isEmpty()) {
                User user = mapDocument(documents.get(0));
                if (user != null) {
                    cacheUser(user);
                    return Optional.of(user);
                }
            }

        } catch (Exception e) {
            log.debug("Firestore findByPhone unavailable, checking local cache: {}", e.getMessage());
        }

        return Optional.ofNullable(normalizedPhone != null ? memoryStoreByPhone.get(normalizedPhone) : null);
    }


    // ============================================================
    // EXISTS BY EMAIL
    // ============================================================

    public boolean existsByEmail(
            String email) {

        return findByEmail(email).isPresent();
    }


    // ============================================================
    // EXISTS BY PHONE
    // ============================================================

    public boolean existsByPhone(
            String phone) {

        return findByPhone(phone).isPresent();
    }


    // ============================================================
    // FIND BY KYC STATUS
    // ============================================================

    public List<User> findByKycStatus(
            User.KycStatus kycStatus) {

        if (kycStatus == null) {
            return List.of();
        }

        try {

            Query query = firestore
                    .collection(COLLECTION)
                    .whereEqualTo(
                            "kycStatus",
                            kycStatus.name()
                    );

            List<QueryDocumentSnapshot> documents =
                    query
                            .get()
                            .get()
                            .getDocuments();

            List<User> users = convertDocuments(documents);
            for (User u : users) cacheUser(u);
            return users;

        } catch (Exception e) {
            log.debug("Firestore findByKycStatus unavailable, filtering local cache: {}", e.getMessage());
            return memoryStoreById.values().stream()
                    .filter(u -> kycStatus.equals(u.getKycStatus()))
                    .toList();
        }
    }


    // ============================================================
    // COUNT BY ROLE
    // ============================================================

    public long countByRole(
            User.Role role) {

        if (role == null) {
            return 0;
        }

        try {

            Query query = firestore
                    .collection(COLLECTION)
                    .whereEqualTo(
                            "role",
                            role.name()
                    );

            return query
                    .get()
                    .get()
                    .size();

        } catch (Exception e) {
            return memoryStoreById.values().stream()
                    .filter(u -> role.equals(u.getRole()))
                    .count();
        }
    }


    // ============================================================
    // COUNT BY STATUS
    // ============================================================

    public long countByStatus(
            User.UserStatus status) {

        if (status == null) {
            return 0;
        }

        try {

            Query query = firestore
                    .collection(COLLECTION)
                    .whereEqualTo(
                            "status",
                            status.name()
                    );

            return query
                    .get()
                    .get()
                    .size();

        } catch (Exception e) {
            return memoryStoreById.values().stream()
                    .filter(u -> status.equals(u.getStatus()))
                    .count();
        }
    }


    // ============================================================
    // COUNT ALL USERS
    // ============================================================

    public long count() {

        return findAll().size();
    }


    // ============================================================
    // FIND ALL
    // ============================================================

    public List<User> findAll() {

        try {

            List<QueryDocumentSnapshot> documents =
                    firestore
                            .collection(COLLECTION)
                            .get()
                            .get()
                            .getDocuments();

            List<User> users = convertDocuments(documents);
            for (User u : users) cacheUser(u);
            return users;

        } catch (Exception e) {
            log.debug("Firestore findAll unavailable, returning local cache: {}", e.getMessage());
            return new ArrayList<>(memoryStoreById.values());
        }
    }


    // ============================================================
    // DELETE
    // ============================================================

    public void deleteById(
            String id) {

        if (id == null || id.isBlank()) {
            return;
        }

        User removed = memoryStoreById.remove(id);
        if (removed != null) {
            if (removed.getEmail() != null) {
                memoryStoreByEmail.remove(removed.getEmail().trim().toLowerCase());
            }
            if (removed.getPhone() != null) {
                String norm = normalizePhoneNumber(removed.getPhone());
                if (norm != null) memoryStoreByPhone.remove(norm);
            }
            if (removed.getProviderUserId() != null) {
                memoryStoreByProvider.remove(removed.getProviderUserId());
            }
        }

        try {

            firestore
                    .collection(COLLECTION)
                    .document(id)
                    .delete()
                    .get();

        } catch (Exception e) {
            log.debug("Firestore deleteById unavailable: {}", e.getMessage());
        }
    }


    // ============================================================
    // MAP DOCUMENT
    // ============================================================

    private User mapDocument(DocumentSnapshot document) {
        if (document == null || !document.exists()) {
            return null;
        }

        try {
            User user = document.toObject(User.class);
            if (user != null) {
                user.setId(document.getId());
                return user;
            }
        } catch (Exception ignored) {
            // Fallback to manual field extraction if schema conversion fails
        }

        User user = new User();
        user.setId(document.getId());
        user.setName(document.getString("name"));
        user.setEmail(document.getString("email"));
        user.setPasswordHash(document.getString("passwordHash"));
        user.setPhone(document.getString("phone"));

        String roleStr = document.getString("role");
        if (roleStr != null) {
            try { user.setRole(User.Role.valueOf(roleStr)); } catch (Exception ignored) {}
        }
        String statusStr = document.getString("status");
        if (statusStr != null) {
            try { user.setStatus(User.UserStatus.valueOf(statusStr)); } catch (Exception ignored) {}
        }
        String kycStatusStr = document.getString("kycStatus");
        if (kycStatusStr != null) {
            try { user.setKycStatus(User.KycStatus.valueOf(kycStatusStr)); } catch (Exception ignored) {}
        }

        user.setAvatarUrl(document.getString("avatarUrl"));
        user.setLoginProvider(document.getString("loginProvider"));
        user.setProviderUserId(document.getString("providerUserId"));
        user.setKycDocumentType(document.getString("kycDocumentType"));
        user.setKycDocumentUrl(document.getString("kycDocumentUrl"));
        user.setMembershipLevel(document.getString("membershipLevel"));

        // Map providerData list
        try {
            var providerDataList = (List<Map<String, Object>>) document.get("providerData");
            if (providerDataList != null && !providerDataList.isEmpty()) {
                List<User.ProviderInfo> providerInfos = new ArrayList<>();
                for (Map<String, Object> providerMap : providerDataList) {
                    User.ProviderInfo providerInfo = new User.ProviderInfo();
                    providerInfo.setProviderId((String) providerMap.get("providerId"));
                    providerInfo.setUid((String) providerMap.get("uid"));
                    providerInfo.setDisplayName((String) providerMap.get("displayName"));
                    providerInfo.setEmail((String) providerMap.get("email"));
                    providerInfo.setPhotoURL((String) providerMap.get("photoURL"));
                    providerInfo.setPhoneNumber((String) providerMap.get("phoneNumber"));
                    providerInfos.add(providerInfo);
                }
                user.setProviderData(providerInfos);
            }
        } catch (Exception e) {
            // If providerData mapping fails, leave it null
            log.debug("Failed to map providerData: {}", e.getMessage());
        }

        Long points = document.getLong("rewardPoints");
        if (points != null) {
            user.setRewardPoints(points.intValue());
        }

        Boolean emailVerified = document.getBoolean("emailVerified");
        if (emailVerified != null) {
            user.setEmailVerified(emailVerified);
        }
        Boolean phoneVerified = document.getBoolean("phoneVerified");
        if (phoneVerified != null) {
            user.setPhoneVerified(phoneVerified);
        }
        Boolean accountLocked = document.getBoolean("accountLocked");
        if (accountLocked != null) {
            user.setAccountLocked(accountLocked);
        }

        user.setCreatedAt(parseInstantField(document.get("createdAt")));
        user.setUpdatedAt(parseInstantField(document.get("updatedAt")));
        user.setLastLoginAt(parseInstantField(document.get("lastLoginAt")));

        return user;
    }

    private Instant parseInstantField(Object value) {
        if (value == null) return Instant.now();
        if (value instanceof com.google.cloud.Timestamp ts) {
            return ts.toDate().toInstant();
        }
        if (value instanceof java.util.Date d) {
            return d.toInstant();
        }
        if (value instanceof String s) {
            try {
                return Instant.parse(s);
            } catch (Exception ignored) {}
        }
        if (value instanceof Number n) {
            return Instant.ofEpochMilli(n.longValue());
        }
        return Instant.now();
    }


    // ============================================================
    // CONVERT FIRESTORE DOCUMENTS
    // ============================================================

    private List<User> convertDocuments(
            List<QueryDocumentSnapshot> documents) {

        List<User> users =
                new ArrayList<>();

        for (QueryDocumentSnapshot document :
                documents) {

            User user = mapDocument(document);

            if (user != null) {
                users.add(user);
            }
        }

        return users;
    }


    // ============================================================
    // NORMALIZE PHONE
    // ============================================================

    private String normalizePhoneNumber(
            String phone) {

        if (phone == null
                || phone.isBlank()) {

            return null;
        }

        String original =
                phone.trim();

        if (original.startsWith("+")) {

            String digits =
                    original.substring(1)
                            .replaceAll(
                                    "[^0-9]",
                                    ""
                            );

            return digits.isBlank()
                    ? null
                    : "+" + digits;
        }

        String cleaned =
                original.replaceAll(
                        "[^0-9]",
                        ""
                );

        if (cleaned.length() == 10) {
            return "+91" + cleaned;
        }

        if (cleaned.length() == 11
                && cleaned.startsWith("0")) {

            return "+91"
                    + cleaned.substring(1);
        }

        if (cleaned.length() == 12
                && cleaned.startsWith("91")) {

            return "+" + cleaned;
        }

        if (cleaned.length() > 10) {
            return "+" + cleaned;
        }

        return "+" + cleaned;
    }
}